# Frontend Placeholder
Use `create-react-app` to generate frontend and add files here.
